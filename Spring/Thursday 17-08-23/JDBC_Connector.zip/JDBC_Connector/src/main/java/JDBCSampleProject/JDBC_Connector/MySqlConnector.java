package JDBCSampleProject.JDBC_Connector;
import java.sql.*;
public class MySqlConnector {
	
	public static final String URL="jdbc:mysql://localhost:3306/mysql";
	public static final String USERNAME="root";
	public static final String PASSWORD="1234";
	Connection con;
	Statement stat;
	
	public void dbConnect() {
		try {
			con=DriverManager.getConnection(URL,USERNAME,PASSWORD);
			System.out.println("connection established");
			System.out.println(con.getMetaData().getDatabaseProductName());
			System.out.println(con.getClientInfo());
			
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public void executeStatements() {
		
		String query="create table items(itemid int primary key, itemname varchar(20),itemprice float,itemquantity int)";
		
		try {
			stat=con.createStatement();
			boolean result=stat.execute(query);
			if(result) {
				System.out.println("table not  created");
			}else {
				System.out.println("table created");
			}
			
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public void insertRecords() {
		String insertCommand="insert into items values(2,'Tea',15,20)";
		try {
		int recordsaffected=stat.executeUpdate(insertCommand);
		System.out.println("record inserted"+recordsaffected);
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public void getRecords() {
		String query="select * from items";
		try {
			ResultSet result=stat.executeQuery(query);
			while(result.next()) {
			
				int itemid=result.getInt(1);
				String itemname=result.getString(2);
				float itemprice=result.getFloat(3);
				int itemquantity=result.getInt(3);
				
				System.out.println("ItemId: "+itemid);
				System.out.println("Item Name: "+itemname);
				System.out.println("Item Price: "+itemprice);
				System.out.println("Item Quantity: "+itemquantity);
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public void insertItemData(int itemid)
}
