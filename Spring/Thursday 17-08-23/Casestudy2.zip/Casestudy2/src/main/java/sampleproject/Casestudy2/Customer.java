package sampleproject.Casestudy2;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
public class Customer {
	public static final String URL="jdbc:mysql://localhost:3306/mysql";
	public static final String USERNAME="root";
	public static final String PASSWORD="1234";
	Connection con;
	Statement stat;
	public void dbConnect() {
		try {
			con=DriverManager.getConnection(URL,USERNAME,PASSWORD);
			System.out.println("connection established");
			System.out.println(con.getMetaData().getDatabaseProductName());
			System.out.println(con.getClientInfo());
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
public void executeStatements() {
		
		String query="create table Customer(customerid int primary key, firstName varchar(20),lastName varchar(20),phoneNumber varchar(20),bill_amount float,"
				+ "bill_due_date date,customer_address varchar(20),constraint customerfk foreign key(packageid) references Package(packageid))";
		
		try {
			stat=con.createStatement();
			boolean result=stat.execute(query);
			if(result) {
				System.out.println("table not  created");
			}else {
				System.out.println("table created");
			}
			
		}catch(Exception e) {
			System.out.println(e);
		}
	}
public void batchQuery()
{
	try {
		con.setAutoCommit(false);
		stat.addBatch("insert into Customer values(1,'Jenny','J','1234567897','2023-12-12','mysore',123)");
		stat.addBatch("insert into Customer values(2,'James','M','1234567898','2023-12-13','mumbai',23)");
		stat.addBatch("insert into Customer values(3,'Jen','J','1234567899','2023-12-14','delhi',124)");
		int [] results=stat.executeBatch();
		con.commit();
		for(int i:results)
		{
			System.out.println(i);
		}
	}
	catch(Exception e)
	{
		System.out.println(e);
		try
		{
			con.rollback();
		}
		catch(Exception e1) {
			System.out.println(e1);
		}
	}
}
public void executeStatements1() {
	
	String query="create table Package(packageid int primary key,packagename varchar(20),package_rate int,total_days int)";
	
	try {
		stat=con.createStatement();
		boolean result=stat.execute(query);
		if(result) {
			System.out.println("table not  created");
		}else {
			System.out.println("table created");
		}
		
	}catch(Exception e) {
		System.out.println(e);
	}
}
public void batchQuery1()
{
try {
	con.setAutoCommit(false);
	stat.addBatch("insert into Package values(123,'package1',65,12)");
	stat.addBatch("insert into Package values(23,'package2',34,2)");
	stat.addBatch("insert into Package values(124'package3',20',4)");
	int [] results=stat.executeBatch();
	con.commit();
	for(int i:results)
	{
		System.out.println(i);
	}
}
catch(Exception e)
{
	System.out.println(e);
	try
	{
		con.rollback();
	}
	catch(Exception e1) {
		System.out.println(e1);
	}
}
}
public void getrecords1() {
	String query = "select * from Customer";
	try {
		ResultSet results=stat.executeQuery(query);
		while(results.next())
		{
			int customerid=results.getInt("callid");
			String firtsname=results.getString("firstname");
			String lastname=results.getString("lastname");
			String phoneNumber=results.getString("phone number");
			float bill_amount=results.getFloat("custname");
			String bill_due_date=results.getString("calldroprate");
			String customer_address=results.getString("customer address");
			int packageid=results.getInt("packageid");
			
		System.out.println("customerid:"+customerid);
		System.out.println("firtsname:"+firtsname);
		System.out.println("lastname:"+lastname);
		System.out.println("phoneNumber:"+phoneNumber);
		System.out.println("bill_amount:"+bill_amount);
		System.out.println("bill_due_date:"+bill_due_date);
		System.out.println("customer_address:"+customer_address);
		System.out.println("packageid:"+packageid);
		}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}
}
