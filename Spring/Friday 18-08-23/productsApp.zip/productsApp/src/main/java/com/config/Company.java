package com.config;

import org.springframework.stereotype.Component;

@Component
public class Company {

		public String getCompanyInfo() {
			String info="New Tech Corp Itd. 23 old baker street ";
			return info;
		}
}
