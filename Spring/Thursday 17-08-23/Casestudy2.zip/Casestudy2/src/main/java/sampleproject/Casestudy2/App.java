package sampleproject.Casestudy2;


import sampleproject.Casestudy2.Customer;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Customer obj=new Customer();
    	obj.dbConnect();
    	
    }
}
