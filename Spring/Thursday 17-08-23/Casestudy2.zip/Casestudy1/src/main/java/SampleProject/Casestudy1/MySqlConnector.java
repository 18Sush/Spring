package SampleProject.Casestudy1;
import java.sql.*;
public class MySqlConnector {
	public static final String URL="jdbc:mysql://localhost:3306/mysql";
	public static final String USERNAME="root";
	public static final String PASSWORD="1234";
	Connection con;
	Statement stat;
	
	public void dbConnect() {
		try {
			con=DriverManager.getConnection(URL,USERNAME,PASSWORD);
			System.out.println("connection established");
			System.out.println(con.getMetaData().getDatabaseProductName());
			System.out.println(con.getClientInfo());
			
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public void executeStatements() {
		
		String query="create table CallQuality(callid int primary key, phoneno varchar(20), callfeedback varchar(20), callrating int, customername varchar(20), calldroprate int)";
		
		try {
			stat=con.createStatement();
			boolean result=stat.execute(query);
			if(result) {
				System.out.println("table not  created");
			}else {
				System.out.println("table created");
			}
			
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public void insertRecords() {
		//String insertCommand="insert into CallQuality values(2,'8873433421','calldrops happening',3,'Mathew Mandis',32)";
		String insertCommand="insert into CallQuality values(5,'8873401041','Excellent',5,'Alice',40)";
		try {
		int recordsaffected=stat.executeUpdate(insertCommand);
		System.out.println("record inserted"+recordsaffected);
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	
	public void updateRecords() {
		String query="delete from CallQuality where callid=5";
		try {
			int recordsaffected=stat.executeUpdate(query);
			System.out.println("Records Updated: "+recordsaffected);
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	public void getRecords() {
		//String query="select * from CallQuality where calldroprate>30";
		//String query="select * from CallQuality where callrating<4";
		//String query="select * from CallQuality where LENGTH(phoneno)<10";
		String query="select * from CallQuality";
		try {
			ResultSet result=stat.executeQuery(query);
			while(result.next()) {
			
				int callid=result.getInt(1);
				String phoneno=result.getString(2);
				String callfeedback=result.getString(3);
				int callrating=result.getInt(4);
				String customername=result.getString(5);
				int calldroprate=result.getInt(6);
				
				System.out.println("Call ID: "+callid);
				System.out.println("Phone number: "+phoneno);
				System.out.println("Call feedback: "+callfeedback);
				System.out.println("Call rating: "+callrating);
				System.out.println("Customer name: "+customername);
				System.out.println("Call droprate: "+calldroprate);
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	public void showRecords(int callid) {
		String query="select * from CallQuality where callid=?";
		try {
			PreparedStatement stat=con.prepareStatement(query);
			stat.setInt(1,  callid);
			ResultSet result=stat.executeQuery(query);
			while(result.next()) {
			
				int call_id=result.getInt(1);
				String phoneno=result.getString(2);
				String callfeedback=result.getString(3);
				int callrating=result.getInt(4);
				String customername=result.getString(5);
				int calldroprate=result.getInt(6);
				
				System.out.println("Call ID: "+call_id);
				System.out.println("Phone number: "+phoneno);
				System.out.println("Call feedback: "+callfeedback);
				System.out.println("Call rating: "+callrating);
				System.out.println("Customer name: "+customername);
				System.out.println("Call droprate: "+calldroprate);
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	public void insertCallData(int callid, String phoneno, String callfeedback, int callrating, String customername,int calldroprate) {
		String query="insert into CallQuality values(?,?,?,?,?,?)";
		try {
			PreparedStatement stat=con.prepareStatement(query);
			stat.setInt(1,  callid);
			stat.setString(2,  phoneno);
			stat.setString(3,  callfeedback);
			stat.setInt(4,  callrating);
			stat.setString(5,  customername);
			stat.setInt(6,  calldroprate);
			int records_inserted = stat.executeUpdate();
			System.out.println(records_inserted +"record inserted");
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}
