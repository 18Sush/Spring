package SampleProject.Casestudy1;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	MySqlConnector obj=new MySqlConnector();
    	obj.dbConnect();
        //obj.executeStatements();
        //obj.insertRecords();
        //obj.updateRecords();
        
        /*obj.insertCallData(9, "8877115500", "Poor", 1, "Shiv", 40);
        obj.insertCallData(10, "8807110044", "good", 3, "Ana", 50);*/
        
        obj.getRecords();
      
        
    }
}
