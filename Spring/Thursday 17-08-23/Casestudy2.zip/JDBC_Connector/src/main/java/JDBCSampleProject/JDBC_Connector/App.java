package JDBCSampleProject.JDBC_Connector;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	MySqlConnector obj=new MySqlConnector();
    	obj.dbConnect();
        obj.executeStatements();
        //obj.insertRecords();
        obj.getRecords();
    }
}
