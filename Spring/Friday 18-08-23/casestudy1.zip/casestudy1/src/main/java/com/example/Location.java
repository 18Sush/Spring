package com.example;

public class Location {
private String locationName;

public String getLocationName() {
	return locationName;
}

public void setLocationName(String locationName) {
	this.locationName = locationName;
}

public Location(String locationName) {
	super();
	this.locationName = locationName;
}
public Location() {}

}
